-- 3rd question
select campaign_name,
		Round(SUM(base_price * `quantity_sold(before_promo)`)/1000000 ,2) as total_revenue_before_promo,
        Round(SUM(base_price * `quantity_sold(after_promo)`)/1000000 ,2) as total_revenue_after_promo
        from fact_events
	join dim_campaigns ON dim_campaigns.campaign_id = fact_events.campaign_id
    group by campaign_name;