SELECT 
    p.category, 
    p.product_name,
    -- ROUND(SUM(f.base_price * f.`quantity_sold(before_promo)`) / 1000000, 2) AS total_revenue_before_promo,
--     ROUND(SUM(f.base_price * f.`quantity_sold(after_promo)`) / 1000000, 2) AS total_revenue_after_promo,
    ROUND(
        (SUM(f.base_price * f.`quantity_sold(after_promo)`) - SUM(f.base_price * f.`quantity_sold(before_promo)`)) 
        / SUM(f.base_price * f.`quantity_sold(before_promo)`) * 100, 
    2) AS IR_percent, 
    RANK() OVER (ORDER BY 
        (SUM(f.base_price * f.`quantity_sold(after_promo)`) - SUM(f.base_price * f.`quantity_sold(before_promo)`)) 
        / SUM(f.base_price * f.`quantity_sold(before_promo)`) * 100 desc 
    ) AS rank_count
FROM fact_events AS f
JOIN dim_products AS p ON f.product_code = p.product_code 
GROUP BY p.category, p.product_name
ORDER BY rank_count limit 5;
