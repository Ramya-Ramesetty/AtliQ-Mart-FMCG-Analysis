-- 2nd question
select s.city, count(s.store_id) as store_count from dim_stores as s group by s.city order by store_count desc;