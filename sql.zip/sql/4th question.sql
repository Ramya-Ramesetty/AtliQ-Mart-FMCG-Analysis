-- 4th question
SELECT 
    p.category, 
    (SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`)) / SUM(f.`quantity_sold(before_promo)`) * 100 AS ISU, 
    RANK() OVER (ORDER BY 
        (SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`)) / SUM(f.`quantity_sold(before_promo)`) * 100 DESC
    ) AS rank_count
FROM fact_events AS f
JOIN dim_products AS p ON f.product_code = p.product_code 
JOIN dim_campaigns AS c ON f.campaign_id = c.campaign_id 
WHERE c.campaign_name = "Diwali"
GROUP BY p.category
ORDER BY rank_count;
